import React from 'react'


const Home = () => {
    return (
        <div>
            <h1>Home</h1>
            <button type='button'><a href='todo'>Todo</a></button>
            <button type='button'><a href='state'>State</a></button>
            <button type='button'><a href='redux'>Redux</a></button>
            <button type='button'><a href='toolkit'>Toolkit</a></button>
            <button type='button'><a href='reducer'>Reducer</a></button>
            <button type='button'><a href='context'>Context</a></button>
            <button type='button'><a href='fetch'>fetch</a></button>



        </div>
    )
}

export default Home